package com.generico.astronautas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenericoExamenApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenericoExamenApplication.class, args);
	}

}
