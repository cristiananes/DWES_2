package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cristianag47Ev2SeguridadApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cristianag47Ev2SeguridadApplication.class, args);
	}

}
